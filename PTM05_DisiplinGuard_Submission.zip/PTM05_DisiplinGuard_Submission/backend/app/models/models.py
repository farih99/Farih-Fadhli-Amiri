"""
Pydantic models for DisiplinGuard API
Sinkron dengan openapi.yaml (components/schemas)
Stack: FastAPI + Pydantic v2
"""

from datetime import datetime
from enum import Enum
from typing import Optional, List
from pydantic import BaseModel, Field, field_validator, ConfigDict


class DisciplineCategory(str, Enum):
    tinggi = "tinggi"
    sedang = "sedang"
    rendah = "rendah"


# ========== Student ==========
class StudentBase(BaseModel):
    student_code: str = Field(..., min_length=1, max_length=50)
    name: str = Field(..., min_length=1, max_length=150)
    class_name: str = Field(..., min_length=1, max_length=50)
    major: str = Field(..., min_length=1, max_length=100)


class Student(StudentBase):
    id: int
    model_config = ConfigDict(from_attributes=True)


class StudentCreate(StudentBase):
    pass


class AttendanceSummary(BaseModel):
    student_id: int
    attendance_percentage: float = Field(..., ge=0, le=100)
    alpha_count: int = Field(..., ge=0)
    late_count: int = Field(..., ge=0)

    model_config = ConfigDict(from_attributes=True)


class AcademicPerformance(BaseModel):
    student_id: int
    average_score: float = Field(
        ..., description="Rata-rata nilai akademik [ASUMSI-06]"
    )
    model_config = ConfigDict(from_attributes=True)


class StudentDetailResponse(BaseModel):
    data: Student
    attendance: Optional[AttendanceSummary] = None
    academic: Optional[AcademicPerformance] = None


# ========== Prediction (AI) ==========
class PredictionCreateRequest(BaseModel):
    student_id: int = Field(..., ge=1)
    attendance_percentage: float = Field(..., ge=0, le=100)
    alpha_count: int = Field(..., ge=0)
    late_count: int = Field(..., ge=0)
    average_score: float

    @field_validator("attendance_percentage")
    @classmethod
    def validate_attendance(cls, v: float) -> float:
        if not 0 <= v <= 100:
            raise ValueError("attendance_percentage harus antara 0 dan 100")
        return v


class Prediction(BaseModel):
    id: int
    student_id: int
    discipline_category: DisciplineCategory
    risk_score: float = Field(
        ..., description="Skor risiko [ASUMSI-08] skala final belum ditetapkan"
    )
    recommendation: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class PredictionResponse(BaseModel):
    data: Prediction


# ========== Priority & Dashboard ==========
class PriorityStudent(BaseModel):
    student_id: int
    student_name: str
    discipline_category: DisciplineCategory
    risk_score: float


class DashboardSummary(BaseModel):
    total_students: int = Field(..., ge=0)
    high_discipline_count: int = Field(..., ge=0)
    medium_discipline_count: int = Field(..., ge=0)
    low_discipline_count: int = Field(..., ge=0)
    risk_students_count: int = Field(..., ge=0)


class DashboardSummaryResponse(BaseModel):
    data: DashboardSummary


# ========== Monitoring History ==========
class MonitoringHistoryCreateRequest(BaseModel):
    student_id: int = Field(..., ge=1)
    follow_up: str = Field(..., min_length=1)
    notes: Optional[str] = None


class MonitoringHistory(BaseModel):
    id: int
    student_id: int
    follow_up: str
    notes: Optional[str] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class MonitoringHistoryResponse(BaseModel):
    data: MonitoringHistory


# ========== Error ==========
class ErrorDetail(BaseModel):
    code: str
    message: str
    details: Optional[dict] = None


class ErrorResponse(BaseModel):
    error: ErrorDetail
