# PTM-05 Prompt Log — DisiplinGuard

## Ringkasan Penggunaan AI

| No | Target Prompt | Alat AI & Versi | Ringkasan Prompt | Kualitas (1-5) | Revisi Manual |
|----|---------------|-----------------|------------------|----------------|---------------|
| 1 | D.1 OpenAPI | Grok / GPT-4o | Buat OpenAPI 3.0 YAML untuk DisiplinGuard berdasarkan LLD + User Stories Must Have + fitur AI | 4 | Ya – tambah tag AI, response 503, field input AI spesifik |
| 2 | D.2 ERD/Skema | Grok / GPT-4o | Buat ERD Mermaid + skema Pydantic dari OpenAPI + LLD (FastAPI+Pydantic) | 4 | Ya – tambah validator, pemisahan Attendance & Academic, mapping endpoint |
| 3 | Iterasi lanjutan | Grok / GPT-4o | Perbaiki fallback AI, sinkronisasi field OpenAPI–Pydantic, lengkapi constraint bisnis | 5 | Minor – penyesuaian deskripsi dan penambahan [ASUMSI-XX] |

## Detail Iterasi

### Prompt D.1 (OpenAPI)
**Masalah output pertama:**
- Endpoint masih generik
- Belum ada tag `AI`
- Belum ada response 503 untuk fallback
- Field request belum spesifik 4 indikator input AI

**Revisi yang dilakukan:**
- Spesifikkan `POST /predictions` dengan field: `student_id`, `attendance_percentage`, `alpha_count`, `late_count`, `average_score`
- Tambah tag `AI`
- Tambah response 503 (`AI_UNAVAILABLE` / `AI_TIMEOUT`)
- Lengkapi error schema seragam

### Prompt D.2 (ERD + Pydantic)
**Masalah output pertama:**
- Relasi ERD belum lengkap
- Belum ada validator rentang `attendance_percentage` 0–100
- Skala `risk_score` belum jelas

**Revisi yang dilakukan:**
- Tambah entitas `ATTENDANCE_SUMMARY` dan `ACADEMIC_PERFORMANCE`
- Tambah `@field_validator` untuk `attendance_percentage`
- Tandai `risk_score` sebagai [ASUMSI-08]
- Buat tabel mapping entitas ↔ endpoint

## Daftar Asumsi

| Kode | Isi Asumsi | Verifikasi Tim |
|------|-----------|----------------|
| ASUMSI-01 | URL production menggunakan placeholder https://api.example.com/api | Benar (sementara) |
| ASUMSI-02 | Mekanisme autentikasi menggunakan Bearer Token (JWT) | Benar |
| ASUMSI-03 | Filter `category` pada `/priority-students` bersifat opsional | Benar |
| ASUMSI-06 | Rentang nilai akademik mengikuti aturan sekolah | Benar |
| ASUMSI-07 | Latensi prediksi ≤ 3 detik | Benar (dari NFR-03) |
| ASUMSI-08 | Skala `risk_score` final belum ditetapkan | Benar |
| ASUMSI-12 | Entitas USER ditambahkan untuk mendukung autentikasi | Benar |

## Deklarasi Penggunaan AI
Tim menggunakan AI (Grok / GPT-4o) sebagai co-pilot untuk menyusun draft OpenAPI, ERD, dan skema Pydantic. Seluruh keputusan desain, constraint bisnis, dan penyesuaian final dilakukan dan diverifikasi oleh tim. AI tidak menggantikan pemahaman terhadap requirement.
