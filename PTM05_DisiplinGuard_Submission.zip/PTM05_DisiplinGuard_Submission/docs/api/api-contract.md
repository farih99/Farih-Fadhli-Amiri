# API Contract DisiplinGuard

## Keputusan Desain

### 1. Stack
- **Backend**: FastAPI (Python) + Pydantic v2
- **Database**: PostgreSQL (production) / SQLite (prototype)
- **AI Service**: Python + scikit-learn (Naive Bayes sebagai baseline)

### 2. Naming Convention
- Resource menggunakan **noun jamak**: `/students`, `/predictions`, `/priority-students`
- Path parameter menggunakan `snake_case`: `{student_id}`, `{prediction_id}`
- Response body dibungkus dalam objek `data` untuk konsistensi

### 3. Autentikasi
- Menggunakan **Bearer Token (JWT)** [ASUMSI-02]
- Semua endpoint dilindungi kecuali health-check (jika ada)

### 4. Fitur AI
- Endpoint utama: `POST /predictions`
- Input wajib: `student_id`, `attendance_percentage`, `alpha_count`, `late_count`, `average_score`
- Output: `discipline_category` (tinggi/sedang/rendah), `risk_score`, `recommendation`
- Fallback: HTTP 503 dengan kode `AI_UNAVAILABLE` atau `AI_TIMEOUT`
- Target latensi: ≤ 3 detik [ASUMSI-07]
- Target akurasi model: ≥ 77%

### 5. Error Handling
Setiap endpoint memiliki minimal respons:
- 2xx (sukses)
- 4xx (kesalahan klien: 400, 401, 404, 422)
- 5xx (kesalahan server: 500, 503 untuk AI)

Format error seragam:
```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Data masukan belum lengkap atau tidak sesuai format.",
    "details": null
  }
}
```

### 6. Constraint Bisnis
| Field | Constraint |
|-------|----------|
| student_code | UNIQUE |
| discipline_category | ENUM: tinggi, sedang, rendah |
| attendance_percentage | 0 ≤ value ≤ 100 |
| alpha_count, late_count | ≥ 0 |
| risk_score | float (skala final [ASUMSI-08]) |
| average_score | mengikuti aturan sekolah [ASUMSI-06] |

### 7. Mapping Endpoint ↔ FR
| Endpoint | FR / User Story |
|----------|-----------------|
| GET /students | FR-02, US-01 |
| GET /students/{id} | FR-02, US-01 |
| GET /students/{id}/attendance | FR-03, FR-04, FR-05, US-02–04 |
| GET /students/{id}/academic | FR-06, US-05 |
| POST /predictions ★ | FR-07, FR-08, FR-09, US-06–08 |
| GET /predictions/{id} ★ | FR-07, FR-08, FR-09 |
| GET /priority-students | FR-10, US-10 |
| GET /dashboard/summary | FR-01, US-14 |
| POST /monitoring-history | FR-13, US-13 |
| GET /monitoring-history/{id} | FR-13, US-13 |

### 8. Asumsi yang Dicatat
- [ASUMSI-01] URL production masih placeholder
- [ASUMSI-02] Auth menggunakan Bearer JWT
- [ASUMSI-06] Rentang nilai akademik belum ditetapkan
- [ASUMSI-07] Latensi prediksi ≤ 3 detik
- [ASUMSI-08] Skala risk_score final belum ditetapkan
- [ASUMSI-12] Entitas USER ditambahkan untuk autentikasi
