# ERD DisiplinGuard

## Diagram Mermaid

```mermaid
erDiagram
    STUDENT {
        int id PK
        string student_code UK
        string name
        string class_name
        string major
        datetime created_at
        datetime updated_at
    }

    ATTENDANCE_SUMMARY {
        int id PK
        int student_id FK
        float attendance_percentage
        int alpha_count
        int late_count
        datetime recorded_at
    }

    ACADEMIC_PERFORMANCE {
        int id PK
        int student_id FK
        float average_score
        datetime recorded_at
    }

    PREDICTION {
        int id PK
        int student_id FK
        string discipline_category
        float risk_score
        string recommendation
        datetime created_at
    }

    MONITORING_HISTORY {
        int id PK
        int student_id FK
        string follow_up
        string notes
        datetime created_at
    }

    USER {
        int id PK
        string username UK
        string full_name
        string role
        string password_hash
        datetime created_at
    }

    STUDENT ||--o{ ATTENDANCE_SUMMARY : "has"
    STUDENT ||--o{ ACADEMIC_PERFORMANCE : "has"
    STUDENT ||--o{ PREDICTION : "has"
    STUDENT ||--o{ MONITORING_HISTORY : "has"
```

## Keterangan

| Entitas | PK | FK | Keterangan |
|----------|----|----|----------|
| STUDENT | id | - | Data master siswa |
| ATTENDANCE_SUMMARY | id | student_id | Indikator absensi (historis) |
| ACADEMIC_PERFORMANCE | id | student_id | Prestasi akademik (historis) |
| PREDICTION | id | student_id | Hasil prediksi AI |
| MONITORING_HISTORY | id | student_id | Riwayat tindak lanjut |
| USER | id | - | Pengguna sistem (Guru BK / Wali Kelas) [ASUMSI-12] |

## Constraint Bisnis

- `student_code` UNIQUE
- `discipline_category` ENUM (`tinggi`, `sedang`, `rendah`)
- `attendance_percentage` antara 0–100
- `alpha_count` ≥ 0
- `late_count` ≥ 0
- `risk_score` float (skala final belum ditetapkan → [ASUMSI-08])
- `average_score` mengikuti aturan sekolah → [ASUMSI-06]
