# PTM-05 IMWAD — DisiplinGuard

## Isi Paket
- LKP-PTM-05-IMWAD-Terisi.docx  → Lembar kerja praktikum yang sudah diisi
- docs/api/openapi.yaml         → Spesifikasi REST API (OpenAPI 3.0)
- docs/api/api-contract.md      → Dokumentasi keputusan desain API
- docs/db/erd.md                → Entity Relationship Diagram (Mermaid)
- backend/app/models/models.py  → Skema data Pydantic v2
- docs/prompt-log/ptm-05-prompt-log.md → Log penggunaan & evaluasi prompt AI

## Commit message (wajib)
feat(api-contract): add OpenAPI spec, ERD, Pydantic schema [PTM-05]

## Stack
- Backend: FastAPI + Pydantic v2
- Database: PostgreSQL / SQLite
- AI: Python + scikit-learn (Naive Bayes baseline)
